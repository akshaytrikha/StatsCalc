import UIKit
import XCPlayground
import PlaygroundSupport

PlaygroundPage.current.liveView = mainView
PlaygroundPage.current.needsIndefiniteExecution = true

public var x = 0.0
public var μ = 0.0
public var σ = 0.0


public let mainView = UIView()

setupfirstScreen(mainn: mainView)






//
//
//
//// graph code
//
//var points = [CGPoint](repeating : CGPoint(x : 0.0, y : 0.0), count : 10) // declares an array of 10 CGPoints(0,0)
//
//for i in 0 ... points.count - 1 {                                    // increases x value of Points by 1
//    points[i].x = CGFloat(i)
//    points[i].y = CGFloat(normalPDF(x: Double(points[i].x), μ: 2, σ: 0.5))
//}
//
//print(points[1])
//
////var bounds = CGRect(x: 100, y: 100, width: 100, height: 100)
//
////points[0] = CGPoint(, y: 0.25 * bounds.size.height)
////points[1] = CGPoint(x: 0.25 * bounds.size.width, y: 0.75 * bounds.size.height)
////points[2] = CGPoint(x: 0.75 * bounds.size.width, y: 0.75 * bounds.size.height)
////points[3] = CGPoint(x: 0.75 * bounds.size.width, y: 0.25 * bounds.size.height)
//








// drawing paths


//let circlePath = UIBezierPath(arcCenter: CGPoint(x: 100,y: 100), radius: CGFloat(20), startAngle: CGFloat(0), endAngle:CGFloat(M_PI * 2), clockwise: true)
//
//let shapeLayer = CAShapeLayer()
//shapeLayer.path = circlePath.cgPath
//
////change the fill color
//shapeLayer.fillColor = UIColor.clear.cgColor
////you can change the stroke color
//shapeLayer.strokeColor = UIColor.red.cgColor
////you can change the line width
//shapeLayer.lineWidth = 3.0
//
//mainView.layer.addSublayer(shapeLayer)

