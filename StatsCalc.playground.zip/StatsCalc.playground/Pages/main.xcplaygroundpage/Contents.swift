import Foundation
import UIKit
import XCPlayground
import PlaygroundSupport

mainInstance.runMain(view: mainInstance.mainView)

PlaygroundPage.current.liveView = mainInstance.mainView
PlaygroundPage.current.needsIndefiniteExecution = true
