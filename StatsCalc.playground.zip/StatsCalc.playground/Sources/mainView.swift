import Foundation
import UIKit

// an enum to determine distinguish between the different buttons 

enum MainButtonType: Int {
    case Normal = 1
    case Poisson = 2
    case Geometric = 3
    case Binomial = 4
    case NegBinomial = 5
}

public class Main {
    
    public init () {
    }
    
    // creating a universal base view
    public let mainView = UIView(frame: CGRect(x: 0, y: 0, width: 360, height: 640))
    
    // variables for all the distributions to use
    public var x = 0.0
    public var μ = 0.0
    public var σ = 0.0
    public var λ = 0.0

    
    // declaring elements on this page:
    
    public let mainTitleLabel = UILabel()
    public let normalButton = UIButton(type: .custom)
    public let poissonButton = UIButton(type: .custom)
    public let binomialButton = UIButton(type: .custom)
    public let geometricButton = UIButton(type: .custom)
    public let negBinomialButton = UIButton(type: .custom)
    
    // function to clear screen
    
    public func clearMainScreen() {
        mainTitleLabel.removeFromSuperview()
        normalButton.removeFromSuperview()
        poissonButton.removeFromSuperview()
        binomialButton.removeFromSuperview()
        geometricButton.removeFromSuperview()
        negBinomialButton.removeFromSuperview()
    }
    
    @objc func tap(button: UIButton) {
        
        clearMainScreen()
        
        // switch statement to determine where the user tapped
        
        switch button.tag {
        case 1:
            print("normal button pressed")
            
            let newMainInstance = Main()
            
            let normalInstance = Normal()
            
            normalInstance.runNormal(view: newMainInstance.mainView)
            break
            
        case 2:
            print("poisson button pressed")
            
            let newMainInstance = Main()
            
            let normalInstance = Normal()
            
            normalInstance.runNormal(view: newMainInstance.mainView)
            break
            
        case 3:
            print("geometric button pressed")
            
            let newMainInstance = Main()
            
            let normalInstance = Normal()
            
            normalInstance.runNormal(view: newMainInstance.mainView)
            break
            
        case 4:
            print("binomial button pressed")
            
            let newMainInstance = Main()
            
            let normalInstance = Normal()
            
            normalInstance.runNormal(view: newMainInstance.mainView)
            break
            
        case 5:
            print("negBinomial button pressed")
            let newMainInstance = Main()
            
            let normalInstance = Normal()
            
            normalInstance.runNormal(view: newMainInstance.mainView)
            break
            
        default:
            print("whoops, please try again")
        }
        
    }
    
    // a function to setup the main view with specified values

    public func runMain(view : UIView) {
        
        view.backgroundColor = UIColor(red: 4/255, green: 112/255, blue: 177/255, alpha: 1)
        
        view.layer.cornerRadius = 7
        view.layer.borderColor = UIColor.white.cgColor
        view.layer.borderWidth = 1
        
        // labels
        
        mainTitleLabel.text = "Stats Distributions"
        mainTitleLabel.textColor = UIColor.white
        mainTitleLabel.font = UIFont(name: "Helvetica-Light", size: 26.0)
        mainTitleLabel.frame = CGRect(x: 0, y: 10, width: 250, height: 40)
        mainTitleLabel.center.x = view.frame.width * 0.57
        
        // buttons
        
        normalButton.frame = CGRect(x: 0, y: 150, width: 375/3, height: 375/3)
        normalButton.center.x = view.frame.width * 0.3
        normalButton.layer.cornerRadius = 0.5 * normalButton.bounds.size.width
        normalButton.clipsToBounds = true
        normalButton.tag = MainButtonType.Normal.rawValue
        normalButton.setImage(UIImage(named:"normalCircle.png"), for: .normal)
        
        poissonButton.frame = CGRect(x: 0, y: 150, width: 375/3, height: 375/3)
        poissonButton.center.x = view.frame.width * 0.7
        poissonButton.layer.cornerRadius = 0.5 * normalButton.bounds.size.width
        poissonButton.clipsToBounds = true
        poissonButton.tag = MainButtonType.Poisson.rawValue
        poissonButton.setImage(UIImage(named:"poissonCircle.png"), for: .normal)
        
        binomialButton.frame = CGRect(x: 0, y: 290, width: 375/3, height: 375/3)
        binomialButton.center.x = view.frame.width * 0.3
        binomialButton.layer.cornerRadius = 0.5 * normalButton.bounds.size.width
        binomialButton.clipsToBounds = true
        binomialButton.tag = MainButtonType.Binomial.rawValue
        binomialButton.setImage(UIImage(named:"binomialCircle.png"), for: .normal)
        
        geometricButton.frame = CGRect(x: 0, y: 290, width: 375/3, height: 375/3)
        geometricButton.center.x = view.frame.width * 0.7
        geometricButton.layer.cornerRadius = 0.5 * normalButton.bounds.size.width
        geometricButton.clipsToBounds = true
        geometricButton.tag = MainButtonType.Geometric.rawValue
        geometricButton.setImage(UIImage(named:"geometricCircle.png"), for: .normal)
        
        negBinomialButton.frame = CGRect(x: 0, y: 430, width: 375/3, height: 375/3)
        negBinomialButton.center.x = view.frame.width * 0.5
        negBinomialButton.layer.cornerRadius = 0.5 * normalButton.bounds.size.width
        negBinomialButton.clipsToBounds = true
        negBinomialButton.tag = MainButtonType.NegBinomial.rawValue
        negBinomialButton.setImage(UIImage(named: "negBinomialCircle.png"), for: .normal)
        
        // adding targets to buttons to enable user interaction
        
        normalButton.addTarget(self, action: #selector(self.tap), for: .touchUpInside)
        poissonButton.addTarget(self, action: #selector(self.tap), for: .touchUpInside)
        geometricButton.addTarget(self, action: #selector(self.tap), for: .touchUpInside)
        binomialButton.addTarget(self, action: #selector(self.tap), for: .touchUpInside)
        negBinomialButton.addTarget(self, action: #selector(self.tap), for: .touchUpInside)
        
        // adding UIElements to the view so they can be seen
        
        view.addSubview(mainTitleLabel)
        view.addSubview(normalButton)
        view.addSubview(poissonButton)
        view.addSubview(binomialButton)
        view.addSubview(geometricButton)
        view.addSubview(negBinomialButton)
    }
}

// declaring an instance of this class to be used throughout the application

public let mainInstance = Main()
