import Foundation
import UIKit

enum SliderType: Int {
    case mu = 1
    case sigma = 2
}

public class Normal {
    
    public init () {
        
        mainInstance.μ = 5.0
        mainInstance.σ = 5.0
    }
    
    // declaring elements on this page:
    
    public let normalTitleLabel = UILabel()
    public let xTextField = UITextField()
    public let muTextField = UITextField()
    public let sigmaTextField = UITextField()
    public let muSlider = UISlider()
    public let sigmaSlider = UISlider()
    
    // function to clear screen
    
    public func clearNormalScreen() {
        normalTitleLabel.removeFromSuperview()
        muSlider.removeFromSuperview()
        sigmaSlider.removeFromSuperview()
    }
    
    // function to resize image (needed to set sliders' images)
    
    public func resizeImage(image: UIImage, newWidth: CGFloat) -> UIImage {
        
        let scale = newWidth / image.size.height
        let newHeight = image.size.height * scale
        
        UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
        
        image.draw(in: CGRect(x: 0, y: 0,width: newWidth, height: newHeight))
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    // function performed when user hits enter on keyboard
    
    @objc func returnKey(textField: UITextField) {

        print("rohan is fat this is working")
        
        if (xTextField.text == "" || muTextField.text == "" || sigmaTextField.text == "") {
            print("please enter number")
        } else {
            mainInstance.x = Double(xTextField.text!)!
            mainInstance.μ = Double(muTextField.text!)!
            mainInstance.σ = Double(sigmaTextField.text!)!
        }
        print(mainInstance.x, mainInstance.μ, mainInstance.σ)
    }
    
    // function performed when user drags on a slider
    
    @objc func slide(slider: UISlider) {
        
        // switch statement to determine which slider the user used

        switch slider.tag {
            
        case 1:
            mainInstance.μ = Double(muSlider.value)
            print(mainInstance.μ)
            break
            
        case 2:
            mainInstance.σ = Double(sigmaSlider.value)
            sigmaTextField.text = String(mainInstance.σ)
            break
            
        default:
            print("oops something went wrong with the slider")
        }
    }

    public func runNormal(view: UIView) {
        
        // labels
        
        normalTitleLabel.text = "Normal Distribution"
        normalTitleLabel.textColor = UIColor.white
        normalTitleLabel.font = UIFont(name: "Helvetica-Light", size: 26.0)
        normalTitleLabel.frame = CGRect(x: 0, y: 20, width: 250, height: 40)
        normalTitleLabel.center.x = view.frame.width * 0.55
        
        // text fields
        
        xTextField.placeholder = "x"
        xTextField.font = UIFont(name: "HelveticNeue-Light", size: 18.0)
        xTextField.textColor = UIColor.gray
        xTextField.textAlignment = .center
        xTextField.frame = CGRect(x: (view.frame.width / 2) - (xTextField.frame.width / 2) , y: 400, width: 50, height: 50)
        xTextField.backgroundColor = UIColor.white
        xTextField.layer.cornerRadius = 10
        
        muTextField.placeholder = "μ"
        muTextField.font = UIFont(name: "HelveticNeue-Light", size: 18.0)
        muTextField.textColor = UIColor.gray
        muTextField.textAlignment = .center
        muTextField.frame = CGRect(x: (view.frame.width / 2) - (muTextField.frame.width / 2) , y: 490, width: 50, height: 50)
        muTextField.backgroundColor = UIColor.white
        muTextField.layer.cornerRadius = 10
        
        sigmaTextField.placeholder = "σ"
        sigmaTextField.font = UIFont(name: "HelveticNeue-Light", size: 18.0)
        sigmaTextField.textColor = UIColor.gray
        sigmaTextField.textAlignment = .center
        sigmaTextField.frame = CGRect(x: (view.frame.width / 2) - (sigmaTextField.frame.width / 2) , y: 580, width: 50, height: 50)
        sigmaTextField.backgroundColor = UIColor.white
        sigmaTextField.layer.cornerRadius = 10
        
        // sliders for the mean and standard deviation!
        
        muSlider.isContinuous = true
        muSlider.isUserInteractionEnabled = true
        muSlider.minimumValue = 0.0
        muSlider.maximumValue = 10.0
        UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseInOut, animations: {
            self.muSlider.setValue(5.0, animated: true) }, completion: nil)
        muSlider.frame = CGRect(x: (view.frame.width / 12) , y: 450, width: 300, height: 20)
        
            var minMu = UIImage(named: "minMu.png") // need a UIImage object to feed into the other functions
            var maxMu = UIImage(named: "maxMu.png")
    
            minMu = resizeImage(image: minMu!, newWidth: 25)
            maxMu = resizeImage(image: maxMu!, newWidth: 35)
        
        muSlider.minimumValueImage = minMu
        muSlider.maximumValueImage = maxMu
        muSlider.tag = SliderType.mu.rawValue
        
        sigmaSlider.isContinuous = true
        sigmaSlider.isUserInteractionEnabled = true
        sigmaSlider.minimumValue = 0.0
        sigmaSlider.maximumValue = 10.0
        UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseInOut, animations: {
            self.sigmaSlider.setValue(5.0, animated: true) }, completion: nil)
        sigmaSlider.frame = CGRect(x: (view.frame.width / 12) , y: 530, width: 300, height: 20)
    
            var minSigma = UIImage(named: "minSigma.png")
            var maxSigma = UIImage(named: "maxSigma.png")
        
            minSigma = resizeImage(image: minSigma!, newWidth: 25)
            maxSigma = resizeImage(image: maxSigma!, newWidth: 35)
        
        sigmaSlider.minimumValueImage = minSigma
        sigmaSlider.maximumValueImage = maxSigma
        sigmaSlider.tag = SliderType.sigma.rawValue
        
        //creating a normal distribution graph, to be modified by the 2 sliders
        
        // creating an instance of StatsFunctions class to access its logic functions 
        
        let stats = StatsFunctions()
        
        var points = [CGPoint](repeating: CGPoint(x: 0.0,y: 0.0), count: 10) // declares an array of 10 CGPoints(0,0)
        
        for i in 0 ... points.count - 1 {
            points[i] = CGPoint(x: Double(i), y: stats.normalPDF(x: Double(i), μ: mainInstance.μ, σ: mainInstance.σ))
        }

        // adding targets for UIElements for user interactions
        xTextField.addTarget(self, action: #selector(self.returnKey), for: .primaryActionTriggered)
        muTextField.addTarget(self, action: #selector(self.returnKey), for: .primaryActionTriggered)
        sigmaTextField.addTarget(self, action: #selector(self.returnKey), for: .primaryActionTriggered)
        
        
        muSlider.addTarget(self, action: #selector(self.slide), for: .valueChanged)
        sigmaSlider.addTarget(self, action: #selector(self.slide), for: .valueChanged)

        
        mainInstance.mainView.addSubview(normalTitleLabel)
//        mainInstance.mainView.addSubview(xTextField)
//        mainInstance.mainView.addSubview(muTextField)
//        mainInstance.mainView.addSubview(sigmaTextField)
        mainInstance.mainView.addSubview(muSlider)
        mainInstance.mainView.addSubview(sigmaSlider)
    }
}
