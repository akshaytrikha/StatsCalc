import Foundation

// TODO: cleanup numbers[]


//: [Previous](@previous)

import Foundation

// add function

public func add(x: Int ,y: Int) -> Int {
    return x + y
}

// average function

var numbers = [90.0,91.0,72.0,85.0,89.0,69.0,60.0,76.0,81.0]

public func average(numbersArray : [Double]) -> Double {
    var sum = 0.0
    var average = 0.0
    
    for k in 0 ... (numbersArray.count - 1) {
        sum += numbersArray[k]
        print("Rohan is fat")
    }
    
    average = sum / (Double(numbersArray.count))                            // not working
    
    return average
}

// variance function

public func variance(numbersArray : [Double]) -> Double {
    var squaredSum = 0.0
    let meanSquared = average(numbersArray: numbers) * average(numbersArray: numbers)
    
    // where Var(x) = E(x^2) - (E(x)^2)
    
    
    for k in 0 ...  (numbersArray.count - 1) {
        squaredSum += numbersArray[k] * numbersArray[k]
    }
    
    return squaredSum / (Double(numbersArray.count)) - meanSquared
}

// standard deviation function

public func standardDeviation(numbersArray : [Double]) -> Double {
    
    return pow(variance(numbersArray: numbers),0.5)
}

// normal PDF function

public func normalPDF(x : Double, μ : Double, σ : Double) -> Double {
    
    // where the normal function is (1/((2*(σ^2)*pi)^0.5)) * (e^(-(x - mean)^2)/2*σ^2)
    
    let first = pow(1/((2 * (pow(σ, 2)) * 3.14159265359)), 0.5)
    
    let second = pow(2.718281828459045, -(pow(x - μ,2)) / (2 * pow(σ,2)))
    
    return first * second
}

// normal CDF third attempt using t approximation


public func normalCDF(x : Double, μ : Double, σ : Double) -> Double {
    
    return (0.5) * (1 + erf((x - μ) / (σ * pow(2,0.5))))
}

public func erf (x : Double) -> Double {
    
    let sign = (x >= 0 ? 1.0 : -1.0)
    let x = abs(x)
    
    let p   = 0.32759
    let a1  = 0.254829592
    let a2  = -0.284496736
    let a3  = 1.421413741
    let a4  = -1.453152027
    let a5  = 1.061405429
    let eX  = 0.00000015
    let t   = 1 / (1 + (p * x))
    
    let erf  = 1 - (a1*t + a2*t*t + a3*t*t*t + a4*t*t*t*t + a5*t*t*t*t*t) * pow(M_E, -pow(x, 2)) + eX
    
    return sign * erf
}

// factorial function

public func factorial(x : Int) -> Int {
    
    if (x == 1 || x == 0) {
        return 1
    } else {
        return x * factorial(x: x - 1)
    }
    
}

// poisson PDF

func poissonPDF (x : Int, μ : Double) -> Double {
    
    return (pow(μ , Double(x)) * pow(M_E, -μ)) / Double(factorial(x: x))
}

// poisson CDF

public func poissonCDF(x : Int, λ : Double) -> Double {
    
    let first = pow(M_E, -λ)
    
    var second = 0.0
    
    for i in 0 ... x {
        second += ((pow(λ, Double(i)) / Double(factorial(x: i))))
    }
    
    print(first)
    print(second)
    
    return first * second
}

// binomial PDF

public func binomialpDF(n : Int, x : Int, p : Double) -> Double {
    
    
    // where PDF = nCr(n, x) * p^x * (1-p)^n-x
    
    let nCr = factorial(x: n) / (factorial(x: x) * factorial(x: n - x))
    
    let second = pow(p, Double(x)) * pow(1 - p, Double(n - x))
    
    return Double(nCr) * second
}

// binomial CDF

public func binomialCDF(n : Int, x : Int, p : Double) -> Double {
    
    var sum = 0.0
    
    for i in 0 ... x {
        
        sum += Double(factorial(x: n) / (factorial(x: i) * factorial(x: n - i))) * pow(p, Double(i)) * pow(1 - p, Double(n - i))
        
    }
    return sum
}

// geometric PDF

public func geoPDF (x : Int, p : Double) -> (Double, Double, Double){
    
    let μ = 1 / p
    
    let σ2 = (1 - p) / pow(p, 2)
    
    return (p * pow(1 - p, Double(x - 1)), μ, σ2)
}

// geometric CDF

public func geoCDF (x : Int, p : Double) -> (Double, Double, Double) {
    
    let μ = 1 / p
    
    let σ2 = (1 - p) / pow(p, 2)
    
    var sum = 0.0
    
    for i in 1 ... x {
        sum += geoPDF(x: i, p : p).0
    }
    return (sum, μ, σ2)
}

// negative Binomial PDF

public func negBinomialPDF(r : Int, x : Int, p : Double) -> (Double, Double, Double) {
    
    let nCr = (factorial(x: x - 1)) / (factorial(x: r - 1) * factorial(x: x - r))
    
    let second = pow(p, Double(r)) * pow(1 - p, Double(x - r))
    
    let μ = Double(r) / p
    
    let σ2 = (Double(r) * (1 - p)) / pow(p , 2)
    
    return (Double(nCr) * second, μ, σ2)                                        // returns PDF, mean, variance
}


// negative Binomial CDF

public func negBinomialCDF(r : Int, x : Int, p : Double) -> Double {
    
    var sum = 0.0
    
    for i in 0 ... x {
        
        sum += Double(factorial(x: r + i - 1) / (factorial(x: i) * (factorial(x: r - 1)))) * pow(p , Double(r)) * pow(1 - p, Double(i))
        
    }
    return sum
}
